package com.cg.banking.utility;

import java.util.Random;

public class BankingUtility {
	public static Random rand = new Random(); 
}
