package com.cg.banking.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

public class MainClass {

	public static void main(String[] args) throws BankingServicesDownException, CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		ApplicationContext applicationContext= new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices=(BankingServices) applicationContext.getBean("services");

		int customerId=bankingServices.acceptCustomerDetails("Samykya", "Thanuku", "sam.com", "BCPO1234", "hyd", "TG", 1234, "gdk", "TG", 98765);
		int customerId1=bankingServices.acceptCustomerDetails("Karunya", "Thanuku", "binnu.com", "ABCD1234", "GDK", "AP", 4567, "KNR", "TG", 5678);

		bankingServices.openAccount(1,"savings",10000);
		bankingServices.openAccount(2,"current",1000);
		bankingServices.openAccount(2, "savings", 5000);
		
		//System.out.println(bankingServices.getCustomerDetails(1));

		
		//System.out.println(bankingServices.getAccountDetails(1, 3));
		//System.out.println(bankingServices.getAllCustomerDetails());
		//bankingServices.depositAmount(1, 1, 4000);
		//bankingServices.depositAmount(1, 1, 2000);
		//bankingServices.depositAmount(2, 2, 5000);
		//System.out.println(bankingServices.getCustomerDetails(1));
		//System.out.println("success");
		//bankingServices.closeAccount(1, 1);
		//System.out.println("success");
		int a=bankingServices.generateNewPin(1, 1);
		int b=bankingServices.generateNewPin(2, 3);
		//int c=bankingServices.generateNewPin(1, 2);
		//bankingServices.withdrawAmount(2, 3, 2000, b);

		//bankingServices.changeAccountPin(1, 1, a, 1234);
		//bankingServices.changeAccountPin(2, 3, b, 1234);

		bankingServices.fundTransfer(1, 1, 2, 3, 1000, b);

		//bankingServices.fundTransfer(customerIdTo, accountNoTo, customerIdFrom, accountNoFrom, transferAmount, pinNumber);
		//System.out.println(bankingServices.getcustomerAllAccountDetails(1));
		//System.out.println(bankingServices.getAccountAllTransaction(1, 1));

		//bankingServices.openAccount(2,"current",20000);
		//System.out.println(bankingServices.getAllCustomerDetails());
		//System.out.println("sucessfully retrieved");
	}

}


















/*catch (BankingServicesDownException e) {
 * 
			e.printStackTrace();

		}
		catch (InvalidAmountException e) {
			e.printStackTrace();


		}
		catch (CustomerNotFoundException e) {
			e.printStackTrace();

		}
		catch (InvalidAccountTypeException e) {
			e.printStackTrace();

		}
		catch (InsufficientAmountException e) {
			e.printStackTrace();

		}
		catch (AccountNotFoundException e) {
			e.printStackTrace();

		}
		catch (InvalidPinNumberException e) {
			e.printStackTrace();

		}
		catch (AccountBlockedException e) {
			e.printStackTrace();

		}
	}
 */
