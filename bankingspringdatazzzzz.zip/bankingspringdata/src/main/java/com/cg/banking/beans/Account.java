package com.cg.banking.beans;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;



@Entity
public class Account implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long accountNo;
	private float accountBalance;
	private String accountType,status;
	private int pinNumber,pinCounter;
	@ManyToOne
	private Customer customer;
	@OneToMany(mappedBy="account",fetch=FetchType.EAGER)
	@MapKey(name="transactionId")
	Map<Integer,Transaction> transactions = new HashMap<>();
	public Account() {}
	
	public Account(float accountBalance, String accountType) {
		super();
		this.accountBalance = accountBalance;
		this.accountType = accountType;
	}

	public Account(long accountNo, float accountBalance, String accountType, String status, int pinNumber,
			int pinCounter, Customer customer, Map<Integer, Transaction> transactions) {
		super();
		this.accountNo = accountNo;
		this.accountBalance = accountBalance;
		this.accountType = accountType;
		this.status = status;
		this.pinNumber = pinNumber;
		this.pinCounter = pinCounter;
		this.customer = customer;
		this.transactions = transactions;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public int getPinCounter() {
		return pinCounter;
	}

	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Map<Integer, Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(Map<Integer, Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountBalance=" + accountBalance + ", accountType=" + accountType
				+ ", status=" + status + ", pinNumber=" + pinNumber + ", pinCounter=" + pinCounter +  ",transactions=" + transactions + "]";
	}

	
	}
